package com.foodapp.exceptions;

public class OrderException extends Exception{
	
	
	public OrderException() {
		// TODO Auto-generated constructor stub
	}
	
	public OrderException(String message) {
		super(message);
	}
	

}
