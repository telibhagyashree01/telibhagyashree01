package com.foodapp.exceptions;

public class BillException extends Exception{
	
	
	public BillException() {
		// TODO Auto-generated constructor stub
	}

    public BillException(String message) {
        super(message);
    }
}
